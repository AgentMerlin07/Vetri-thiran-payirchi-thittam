Optional: place your LegalEase logo here as assets/logo.png.
