def make_txt(text: str) -> bytes:
    return text.encode("utf-8")
