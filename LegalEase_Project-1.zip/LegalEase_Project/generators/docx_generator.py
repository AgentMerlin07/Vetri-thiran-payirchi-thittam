from io import BytesIO
from docx import Document
from docx.shared import Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH


def make_docx(text: str, document_type: str) -> bytes:
    doc = Document()

    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = title.add_run(document_type or "Legal Document")
    run.bold = True
    run.font.size = Pt(16)

    for block in text.split("\n"):
        p = doc.add_paragraph()
        r = p.add_run(block)
        r.font.name = "Times New Roman"
        r.font.size = Pt(11)

    output = BytesIO()
    doc.save(output)
    return output.getvalue()
