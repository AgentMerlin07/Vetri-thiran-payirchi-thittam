# LegalEase – Team Work Explanation (Tanglish)

## Merlin Ranjitham – Team Lead
SkillWallet:
1. Research and Select the Appropriate Generative AI Model
2. Define the Architecture of the Application
3. Set Up the Development Environment

Work:
- AI model research and selection.
- Overall system architecture.
- Python/venv/packages/.env setup.
- Coordinate all members and integrate their work.

## Thakshitha S
SkillWallet:
1. Pre-requisites
2. Develop the Core Functionalities
3. Implement the FastAPI Backend

Work:
- Check FastAPI, Gemini, Streamlit, Python and required packages.
- Implement legal-document generation and formatting/export.
- Implement backend `/generate` flow.

## Monikka S
SkillWallet:
1. Create and Configure main.py
2. Handle Document Generation Logic in routes.py

Work:
- Initialize FastAPI.
- Add `/` health endpoint.
- Include routes.
- Create Pydantic DocumentRequest.
- Call GeminiDocumentGenerator.
- Implement POST `/generate`.

## Jeevitha
SkillWallet:
1. Workflow
2. Designing and Developing the User Interface
3. Creating Dynamic Previews and Export Options

Work:
- Document the end-to-end workflow.
- Build Streamlit input UI.
- Display generated content.
- Allow editing.
- Provide TXT/DOCX/PDF downloads.

## Rithika Shree S
SkillWallet:
1. Preparing the Application for Local Deployment
2. Testing and Verifying Local Deployment
3. Conclusion

Work:
- Prepare venv, dependencies and .env.
- Test generation, preview, editing and downloads.
- Prepare project conclusion and future enhancements.

## Final flow

User input
-> Streamlit
-> FastAPI
-> Gemini
-> Generated document
-> Preview/Edit
-> TXT/DOCX/PDF
-> GitHub + Demo submission
