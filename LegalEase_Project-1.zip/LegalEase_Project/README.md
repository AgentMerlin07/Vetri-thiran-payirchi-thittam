# LegalEase – AI-Powered Legal Document Generator

LegalEase is a project based on the supplied project specification. It accepts:
- Document type
- Parties involved
- Terms & conditions
- Effective date

It generates legal-document text with Gemini through a FastAPI backend, previews it in Streamlit, and supports TXT, DOCX and PDF export.

## Project structure

```text
LegalEase/
├── backend/
│   ├── main.py
│   └── routes.py
├── ai_core/
│   └── gemini_generator.py
├── generators/
│   ├── txt_generator.py
│   ├── docx_generator.py
│   └── pdf_generator.py
├── frontend/
│   └── app.py
├── assets/
│   └── logo.png              # optional
├── .env.example
├── requirements.txt
└── README.md
```

## Setup

1. Install Python 3.10+.
2. Open this folder in VS Code.
3. Create a virtual environment:

```bash
python -m venv venv
```

Windows:
```bash
venv\Scripts\activate
```

macOS/Linux:
```bash
source venv/bin/activate
```

4. Install packages:

```bash
pip install -r requirements.txt
```

5. Copy `.env.example` to `.env` and add your Gemini API key.

The supplied project document specifies `gemini-1.5-pro` as the selected model. This project keeps the model name configurable through `GEMINI_MODEL`, so it can be changed if the available Gemini API account does not expose that model.

## Run the backend

```bash
uvicorn backend.main:app --reload
```

Backend health check:
`http://127.0.0.1:8000/`

## Run the frontend

In a second terminal:

```bash
streamlit run frontend/app.py
```

The Streamlit page normally opens at:
`http://localhost:8501`

## Important

LegalEase is an educational software project. Generated text should be reviewed by a qualified legal professional before real-world use.
