import os
from dotenv import load_dotenv

load_dotenv()

try:
    import google.generativeai as genai
except ImportError:
    genai = None


class GeminiDocumentGenerator:
    def __init__(self):
        self.api_key = os.getenv("GEMINI_API_KEY")
        self.model_name = os.getenv("GEMINI_MODEL", "gemini-1.5-pro")

        if genai is not None and self.api_key:
            genai.configure(api_key=self.api_key)

    def _build_prompt(self, document_type, parties, terms, dates):
        return f"""
You are LegalEase, an AI assistant for drafting structured legal-document templates.

Create a professional draft for the following inputs.

Document type:
{document_type}

Parties involved:
{parties}

Terms and conditions:
{terms}

Effective date:
{dates}

Requirements:
1. Use clear formal sections and headings.
2. Include the supplied parties, terms and effective date.
3. Do not invent important facts that were not supplied.
4. Mark missing information as [TO BE COMPLETED].
5. Produce a draft for review, not a claim of legal advice.
6. Keep the wording organized and suitable for export to TXT, DOCX and PDF.
"""

    def generate_document(self, document_type, parties, terms, dates):
        if genai is None:
            raise RuntimeError("google-generativeai is not installed. Run: pip install -r requirements.txt")

        if not self.api_key:
            raise RuntimeError(
                "GEMINI_API_KEY is missing. Create a .env file from .env.example and add your API key."
            )

        prompt = self._build_prompt(document_type, parties, terms, dates)
        model = genai.GenerativeModel(self.model_name)
        response = model.generate_content(prompt)

        text = getattr(response, "text", None)
        if not text:
            raise RuntimeError("Gemini returned no text.")
        return text
