import os
import requests
import streamlit as st
from dotenv import load_dotenv

from generators.txt_generator import make_txt
from generators.docx_generator import make_docx
from generators.pdf_generator import make_pdf

load_dotenv()

st.set_page_config(page_title="LegalEase", page_icon="⚖️", layout="wide")

st.title("⚖️ LegalEase")
st.caption("AI-Powered Legal Document Generator")

backend_url = st.sidebar.text_input(
    "Backend URL",
    value=os.getenv("BACKEND_URL", "http://127.0.0.1:8000"),
)

document_type = st.text_input(
    "Document Type",
    placeholder="Example: Employment Contract",
)

parties = st.text_area(
    "Parties Involved",
    placeholder="Example: Jane Doe (Employee), ABC Pvt Ltd (Employer)",
)

terms = st.text_area(
    "Terms & Conditions",
    placeholder="Use semicolons for separate clauses.",
)

dates = st.text_input(
    "Effective Date",
    placeholder="Example: 10/04/2026",
)

if "document" not in st.session_state:
    st.session_state.document = ""

if st.button("Generate Document", type="primary"):
    if not all([document_type.strip(), parties.strip(), terms.strip(), dates.strip()]):
        st.warning("Please fill all required fields.")
    else:
        try:
            response = requests.post(
                f"{backend_url.rstrip('/')}/generate",
                json={
                    "document_type": document_type,
                    "parties": parties,
                    "terms": terms,
                    "dates": dates,
                },
                timeout=120,
            )
            response.raise_for_status()
            st.session_state.document = response.json()["document"]
            st.success("Document generated successfully.")
        except requests.RequestException as exc:
            st.error(f"Backend connection failed: {exc}")
        except Exception as exc:
            st.error(f"Generation failed: {exc}")

if st.session_state.document:
    st.subheader("Document Preview")

    st.markdown(
        f"""
        <div style="
            padding:20px;
            border:1px solid #444;
            border-radius:12px;
            max-height:500px;
            overflow:auto;
            white-space:pre-wrap;
        ">{st.session_state.document}</div>
        """,
        unsafe_allow_html=True,
    )

    st.subheader("Edit Document")
    edited = st.text_area(
        "Click here to edit the generated document",
        value=st.session_state.document,
        height=350,
    )

    st.session_state.document = edited

    col1, col2, col3 = st.columns(3)

    with col1:
        st.download_button(
            "Download TXT",
            data=make_txt(edited),
            file_name="legalease_document.txt",
            mime="text/plain",
        )

    with col2:
        st.download_button(
            "Download DOCX",
            data=make_docx(edited, document_type),
            file_name="legalease_document.docx",
            mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        )

    with col3:
        st.download_button(
            "Download PDF",
            data=make_pdf(edited, document_type),
            file_name="legalease_document.pdf",
            mime="application/pdf",
        )

st.divider()
st.caption("Educational project. Review generated legal text before real-world use.")
